//Name: Evan Trout
//Student ID: 2839780
#include <iostream>

int main(int argc, char** argv)
{
	std::cout << "My name is Evan Trout." << std::endl;
	std::cout << "I am a ChemE major.\n";
	std::cout << "My hobbies are:" << std::endl;
	std::cout << "\tWatching movies and TV\n\tPlaying video games\n\tExercising\n\tCooking\n" << std::endl;
	std::cout << "Goodbye" << std::endl;
}
