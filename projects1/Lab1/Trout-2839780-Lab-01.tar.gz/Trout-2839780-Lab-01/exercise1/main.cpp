//Name: Evan Trout
//Student ID: 2839780

#include <iostream>

int main(int argc, char** argv)
{
	std::cout << "This is my first lab exercise!" << std::endl;
}
