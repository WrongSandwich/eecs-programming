/*******************************************************************************
*@author  Evan Trout
*@file    Checker.cpp
*@date    09/29/2018
*@brief   Implementation file for the executive class Checker. Constructor
*         reads command line argument class's members, then run() removes all
*         filler characters and checks to see if the resulting string is even in
*         length before sending it to test(). Test then checks char-by-char to
*         confirm the string is balanced.
*******************************************************************************/

#include <string>
#include <iostream>
#include "Checker.h"

Checker::Checker(std::string givenStr)
{
    origStr = givenStr;
    str = origStr;
    strLength = str.size();
}

void Checker::run()
{
  str = origStr;
  strLength = str.size();
  //Removing all filler characters
  for (int i = 0; i < strLength; i++)
  {
    if (str.substr(i,1) != "(" && str.substr(i,1) != ")" && str.substr(i,1) != "[" && str.substr(i,1) != "]" && str.substr(i,1) != "{" && str.substr(i,1) != "}")
    {
      str.erase(i,1); //Removing filler character
      strLength = str.size(); //Updating strLength
      i--; //Decreasing i by 1 to offset increase for next loop
    }
  }
  if ((strLength % 2) != 0)//Checking if string is an even number
  {
    std::cout << "The sequence " << origStr << " is not balanced\n";
  }
  else
  {
    test();
  }
}

void Checker::test()
{
  if (strLength == 0) //base case
  {
    std::cout << "The sequence " << origStr << " is balanced\n";
  }
  else //String is not empty
  {
    if (str.substr(0,1) == "(" && str.substr((strLength - 1),1) == ")") //If first and last characters are equal
    {
      str = str.substr(1, (strLength-2));
      strLength = strLength - 2;
      test();
    }
    else if (str.substr(0,1) == ")" && str.substr((strLength - 1),1) == "(")
    {
      str = str.substr(1, (strLength-2));
      strLength = strLength - 2;
      test();
    }
    else if (str.substr(0,1) == "{" && str.substr((strLength - 1),1) == "}")
    {
      str = str.substr(1, (strLength-2));
      strLength = strLength - 2;
      test();
    }
    else if (str.substr(0,1) == "}" && str.substr((strLength - 1),1) == "{")
    {
      str = str.substr(1, (strLength-2));
      strLength = strLength - 2;
      test();
    }
    else if (str.substr(0,1) == "[" && str.substr((strLength - 1),1) == "]")
    {
      str = str.substr(1, (strLength-2));
      strLength = strLength - 2;
      test();
    }
    else if (str.substr(0,1) == "]" && str.substr((strLength - 1),1) == "[")
    {
      str = str.substr(1, (strLength-2));
      strLength = strLength - 2;
      test();
    }
    else
    {
      std::cout << "The sequence " << origStr << " is not balanced\n";
    }
  }
}
